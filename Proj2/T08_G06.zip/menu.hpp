#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

int print_menu();

int select_map();

int show_rules();