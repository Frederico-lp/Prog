#include "game.hpp"

int main(){
    /*
    int option
    option = menu.begin();
    if option == 1
        play_game(map_number)

    */
   return play_game(1);
}